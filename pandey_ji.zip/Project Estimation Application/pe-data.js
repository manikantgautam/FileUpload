
var project_type=[
{
"id":"1",
"name":"Annual Report",
"parent_id":"0",
"imgsrc":"images/b.png"
},
{
"id":"2",
"name":"BOV/Pitch",
"parent_id":"0",
"imgsrc":"images/a.png"
},
{
"id":"3",
"name":"OM",
"parent_id":"0"
},
{
"id":"4",
"name":"Reports/RFP",
"parent_id":"0"
},
{
"id":"5",
"name":"Flyers",
"parent_id":"0"
},
{
"id":"6",
"name":"Whitepapers",
"parent_id":"0"
},
{
"id":"7",
"name":"Interactive",
"parent_id":"0",
"imgsrc":"a.png"
},
{
"id":"8",
"name":"Brochures",
"parent_id":"0"
},
{
"id":"9",
"name":"Guide Book",
"parent_id":"0"
},
{
"id":"10",
"name":"Placemats",
"parent_id":"0"
},
{
"id":"11",
"name":"Conversion (to InDesign)",
"parent_id":"0"
},
{
"id":"12",
"name":"Others",
"parent_id":"0"
},
{
"id":"13",
"name":"Email Banner",
"parent_id":"0"
},
{
"id":"14",
"name":"Website Banner",
"parent_id":"0"
},
{
"id":"15",
"name":"Social Media Post",
"parent_id":"0"
},
{
"id":"16",
"name":"Video Posts",
"parent_id":"0"
},
{
"id":"17",
"name":"Gifs",
"parent_id":"0"
},
{
"id":"18",
"name":"Headshots",
"parent_id":"0"
},
{
"id":"19",
"name":"Image Manipulation",
"parent_id":"0"
},
{
"id":"20",
"name":"Interviews",
"parent_id":"0"
},
{
"id":"21",
"name":"Production",
"parent_id":"0"
},
{
"id":"22",
"name":"Animation",
"parent_id":"0"
},
{
"id":"23",
"name":"Motion Graphics",
"parent_id":"0"
},
{
"id":"24",
"name":"Property Walkthrough",
"parent_id":"0"
},
{
"id":"25",
"name":"Leadership Message",
"parent_id":"0"
},
{
"id":"26",
"name":"Virtual Tour",
"parent_id":"0"
},
{
"id":"27",
"name":"Outlook Mailer",
"parent_id":"0"
},
{
"id":"28",
"name":"Newsletter",
"parent_id":"0"
},
{
"id":"29",
"name":"Poppulo",
"parent_id":"0"
},
{
"id":"30",
"name":"Eloqua",
"parent_id":"0"
},
{
"id":"31",
"name":"Weebly",
"parent_id":"0"
},
{
"id":"32",
"name":"Spark",
"parent_id":"0"
},
{
"id":"33",
"name":"XD",
"parent_id":"0"
},
{
"id":"34",
"name":"Floor Plan",
"parent_id":"0"
},
{
"id":"35",
"name":"Site Plan",
"parent_id":"0"
},
{
"id":"36",
"name":"Amenities Map",
"parent_id":"0"
},
{
"id":"37",
"name":"Tranportation Maps",
"parent_id":"0"
},
{
"id":"38",
"name":"Location Maps",
"parent_id":"0"
},
{
"id":"39",
"name":"Logo Creation",
"parent_id":"0"
},
{
"id":"40",
"name":"Branding",
"parent_id":"0"
},
{
"id":"41",
"name":"Logo Tracing (Vector)",
"parent_id":"0"
},
{
"id":"42",
"name":"Stack Plan",
"parent_id":"0"
},
{
"id":"43",
"name":"Building Illustrations",
"parent_id":"0"
},
{
"name":"InDesign",
"parent_id":"1"

},
{
"name":"Powerpoint",
"parent_id":"1",
"imgsrc":"images/a.png"
},
{
"name":"InDesign",
"parent_id":"2",
"imgsrc":"a.png"
},
{
"name":"Powerpoint",
"parent_id":"2",
"imgsrc":"a.png"
},
{
"name":"InDesign",
"parent_id":"3",
"imgsrc":"a.png"
},
{
"name":"Powerpoint",
"parent_id":"3",
"imgsrc":"b.png"
},
{
"name":"InDesign",
"parent_id":"4",
"imgsrc":"b.png"
},
{
"name":"Powerpoint",
"parent_id":"4",
"imgsrc":"c.png"
},
{
"name":"InDesign",
"parent_id":"5",
"imgsrc":"c.png"
}

]

var table = [
	{"name":"Other","table":[{"fname":"Mani","lName":"gautam","age":27},
	{"fname":"vikas","lName":"pandey","age":37}]},
	
	{"name":"Email Banner","table":[{"fname":"Mani","lName":"gautam","age":27},
	{"fname":"vikas","lName":"pandey","age":37}]},
	
	{"name":"Conversion (To InDesign)","table":[{"fname":"Ashu","lName":"Sharma","age":27},{"fname":"Vashu","lName":"pandey","age":37}
]}];