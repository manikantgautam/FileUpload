

var table_header = "";



function renderProduct(){
project_type.forEach(function(e){
if(e.id){
	let option = `<option id=${e.id}>${e.name}</option>`;
    $("#project_type").append(option);
}
   })


}
renderProduct();

$("#project_type").on("change",function(){
     var val = $(this).val();
	 let elem=project_type.find(e=>e.name==val);
     var children= project_type.filter(e=>e.parent_id==elem.id);
	if(children && children.length>0){
	children.forEach(function(e){
	let option = `<option id=${e.id}>${e.name}</option>`;
	$("#project_category").append(option);
	})
	}else{
	$("#project_category").html('');
	 $("#img").attr("src",'');
	} 
})

$("#project_category").on("change",function(){
	$("#table_id").html('');
	console.log("table data :: - ",data_set);
   	   var val = $(this).val();
	   let parent = $("#project_type").val();
	   let elem=project_type.find(e=>e.name==val);
	   console.log(elem);
	   let tableItem = data_set.find(e=>e.parent==parent && e.child == elem.name);
	   $("#img").attr("src",elem.imgsrc?elem.imgsrc:'');
	   if(tableItem){
		console.log(tableItem);
        $("#table_id").append(tableItem.th_header);
		$("#table_id").append(tableItem.th_body);
		$("#table_id").append(tableItem.th_footer);
		
	   }
	   
	 
})