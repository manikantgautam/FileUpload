

var data_set = [
	{
		"parent" :"Annual Report",
		"child":"InDesign",
		"formula":"multiply",
		"th_header":"<tr style='background:#333;color:white'><th>Project Parameters</th><th>Page(s) or Unit(s)</th><th>Effort per unit (% or mins)</th><th>Total Effort(mins)</th></tr>",
		"th_body":`<tr><td>manukant</td><td>manukant</td><td>manukant</td><td>manukant</td></tr>`,
		"th_footer":`
		   <tfoot>
				<tr style='background:#333;color:white'>
				<th>QC 1st Round (Suggestions & Corrections)</th>
				<th>&nbsp;</th>
				<th>Fixed</th>
				<th>10</th>
				</tr>
				<tr>
				<th>Overall coordination/Communication</th>
				<th>&nbsp;</th>
				<th>15%</th>
				<th>4.5</th>
				</tr>
				<tr>
				<th>QC (Design)</th>
				<th>&nbsp;</th>
				<th>Fixed</th>
				<th>20</th>
				</tr>
				<tr>
				<th>QC (content)</th>
				<th>&nbsp;</th>
				<th>Fixed</th>
				<th>20</th>
				</tr>
				<tr>
				<th>Buffer%</th>
				<th>&nbsp;</th>
				<th>10%</th>
				<th>3.0</th>
				</tr>
				<tr>
				<th colspan="2" rowspan="5">WFC Comments:</th>				
				</tr>
				<tr style="background:#808080;color: white">
				<th>Design Effort</th>				
				<th>1.2</th>
				</tr>
				<tr style="background:#808080;color: white">
				<th>Planned Hours</th>				
				<th>3.0</th>
				</tr>
				<tr style="background:#808080;color: white">
				<th>QC Hours</th>				
				<th>3.0</th>
				</tr>
				<tr style="background: rgb(221,19,6);color: white">
				<th>Total Hours</th>				
				<th>3.0</th>
				</tr>
				</tfoot>
		`
	},
	{
		"parent" :"Broucher",
		"child":"Ed",
		"th_header":"<tr style='background:#333;color:white'><th>Project Parameters</th><th>Page(s) or Unit(s)</th><th>Effort per unit (% or mins)</th><th>Total Effort(mins)</th></tr>",
		"th_footer":"<>"
	},
	{
		"parent" :"Guide Book",
		"child":"Others",
		"th_header":"<tr style='background:#333;color:white'><th>Project Parameters</th><th>Page(s) or Unit(s)</th><th>Effort per unit (% or mins)</th><th>Total Effort(mins)</th></tr>",
		"th_footer":"<>"
	},
	{
		"parent" :"Guid book",
		"child":"Ed",
		"th_header":"<tr style='background:#333;color:white'><th>Project Parameters</th><th>Page(s) or Unit(s)</th><th>Effort per unit (% or mins)</th><th>Total Effort(mins)</th></tr>",
		"th_footer":"<>"
	}
];